/**
 * Seed de démonstration KYC-AML v2
 *
 * Génère un jeu de données réalistes pour le Maroc :
 *   - 1 admin + 3 utilisateurs (analyste, superviseur, compliance officer)
 *   - 20 clients (INDIVIDUAL + CORPORATE, dont 3 PEP, 2 à risque élevé)
 *   - 60 transactions (dont 12 suspectes, 3 bloquées)
 *   - 8 alertes AML (CRITICAL, HIGH, MEDIUM)
 *   - 4 dossiers de conformité
 *   - 6 résultats de screening
 *   - 2 rapports SAR
 *
 * Usage :
 *   pnpm tsx drizzle/seed.demo.ts
 *   pnpm tsx drizzle/seed.demo.ts --reset   (supprime et recrée)
 */

import "../server/_core/env";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import bcrypt from "bcryptjs";
import { nanoid } from "nanoid";
import * as schema from "./schema";
import { eq } from "drizzle-orm";

// ─── Connexion ────────────────────────────────────────────────────────────────

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db   = drizzle(pool, { schema });

const RESET = process.argv.includes("--reset");

// ─── Helpers ──────────────────────────────────────────────────────────────────

const uid  = () => nanoid(10).toUpperCase();
const txId = () => `TXN-AML-${nanoid(8).toUpperCase()}`;
const altId = () => `ALT-${nanoid(8).toUpperCase()}`;
const sarId = () => `SAR-2026-${nanoid(6).toUpperCase()}`;
const caseId = () => `CASE-${nanoid(6).toUpperCase()}`;

function daysAgo(n: number): Date {
  return new Date(Date.now() - n * 86_400_000);
}
function hoursAgo(n: number): Date {
  return new Date(Date.now() - n * 3_600_000);
}

// ─── Reset optionnel ──────────────────────────────────────────────────────────

async function resetDb() {
  console.log("🗑️  Suppression des données existantes...");
  await db.delete(schema.screeningResults);
  await db.delete(schema.cases);
  await db.delete(schema.alerts);
  await db.delete(schema.transactions);
  await db.delete(schema.customers);
  await db.delete(schema.users);
  console.log("   ✓ Tables vidées");
}

// ─── 1. UTILISATEURS ─────────────────────────────────────────────────────────

async function seedUsers() {
  console.log("\n👥 Création des utilisateurs...");

  const hash = (pw: string) => bcrypt.hash(pw, 12);

  const usersData = [
    {
      email:        "admin@labft.ma",
      name:         "Administrateur Système",
      role:         "admin"        as const,
      passwordHash: await hash("Admin2026!LabFT"),
      isActive:     true,
    },
    {
      email:        "analyste@labft.ma",
      name:         "Youssef BENALI",
      role:         "analyst"      as const,
      passwordHash: await hash("Analyst2026!"),
      isActive:     true,
    },
    {
      email:        "superviseur@labft.ma",
      name:         "Fatima EZZAHRAOUI",
      role:         "supervisor"   as const,
      passwordHash: await hash("Superv2026!"),
      isActive:     true,
    },
    {
      email:        "compliance@labft.ma",
      name:         "Khalid MANSOURI",
      role:         "compliance_officer" as const,
      passwordHash: await hash("Compli2026!"),
      isActive:     true,
    },
    {
      email:        "demo@banque.ma",
      name:         "Démo Client Banque",
      role:         "analyst"      as const,
      passwordHash: await hash("Demo2026!"),
      isActive:     true,
    },
  ];

  const inserted = await db.insert(schema.users).values(usersData).returning();
  console.log(`   ✓ ${inserted.length} utilisateurs créés`);
  console.log("   Comptes disponibles :");
  console.log("     admin@labft.ma        / Admin2026!LabFT   (admin)");
  console.log("     analyste@labft.ma     / Analyst2026!      (analyst)");
  console.log("     superviseur@labft.ma  / Superv2026!       (supervisor)");
  console.log("     compliance@labft.ma   / Compli2026!       (compliance_officer)");
  console.log("     demo@banque.ma        / Demo2026!         (analyst — pour démos)");

  return inserted;
}

// ─── 2. CLIENTS ──────────────────────────────────────────────────────────────

async function seedCustomers(users: typeof schema.users.$inferSelect[]) {
  console.log("\n🏦 Création des clients...");

  const analyst = users.find(u => u.role === "analyst")!;

  const customersData = [

    // ── Clients INDIVIDUAL normaux ────────────────────────────────────────────
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "Mohammed",
      lastName:        "ALAMI",
      email:           "m.alami@gmail.com",
      phone:           "+212661234501",
      dateOfBirth:     "1978-03-15",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "12 Rue Ibn Batouta, Quartier Gauthier",
      city:            "Casablanca",
      profession:      "Ingénieur",
      employer:        "OCP Group",
      sourceOfFunds:   "Salaire",
      customerType:    "INDIVIDUAL" as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "LOW"        as const,
      riskScore:       12,
      pepStatus:       false,
      sanctionStatus:  "CLEAR"      as const,
      lastReviewDate:  daysAgo(90),
      nextReviewDate:  daysAgo(-275),
      assignedAnalyst: analyst.id,
    },
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "Aicha",
      lastName:        "BERRADA",
      email:           "a.berrada@hotmail.com",
      phone:           "+212662345602",
      dateOfBirth:     "1985-07-22",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "45 Avenue Hassan II",
      city:            "Rabat",
      profession:      "Médecin",
      employer:        "CHU Rabat",
      sourceOfFunds:   "Salaire",
      customerType:    "INDIVIDUAL" as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "LOW"        as const,
      riskScore:       8,
      pepStatus:       false,
      sanctionStatus:  "CLEAR"      as const,
      lastReviewDate:  daysAgo(45),
      nextReviewDate:  daysAgo(-320),
      assignedAnalyst: analyst.id,
    },
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "Karim",
      lastName:        "TAZI",
      email:           "k.tazi@yahoo.fr",
      phone:           "+212663456703",
      dateOfBirth:     "1990-11-08",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "7 Rue Moulay Ali Cherif",
      city:            "Fès",
      profession:      "Commerçant",
      sourceOfFunds:   "Commerce",
      customerType:    "INDIVIDUAL" as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "MEDIUM"     as const,
      riskScore:       35,
      pepStatus:       false,
      sanctionStatus:  "CLEAR"      as const,
      lastReviewDate:  daysAgo(60),
      nextReviewDate:  daysAgo(-305),
      assignedAnalyst: analyst.id,
    },

    // ── Client PEP (Personne Politiquement Exposée) ───────────────────────────
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "Rachid",
      lastName:        "BENSOUDA",
      email:           "r.bensouda@gov.ma",
      phone:           "+212664567804",
      dateOfBirth:     "1965-04-30",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "1 Avenue Mohamed V",
      city:            "Rabat",
      profession:      "Haut Fonctionnaire",
      employer:        "Ministère des Finances",
      sourceOfFunds:   "Salaire public",
      customerType:    "INDIVIDUAL" as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "HIGH"       as const,
      riskScore:       72,
      pepStatus:       true,
      sanctionStatus:  "CLEAR"      as const,
      notes:           "PEP confirmé — Directeur Général Trésorerie. Surveillance renforcée AMLD6 Art. 18.",
      lastReviewDate:  daysAgo(30),
      nextReviewDate:  daysAgo(-335),
      assignedAnalyst: analyst.id,
    },
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "Nadia",
      lastName:        "EL FASSI",
      email:           "n.elfassi@parlement.ma",
      phone:           "+212665678905",
      dateOfBirth:     "1972-09-14",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "23 Rue de la Chambre des Représentants",
      city:            "Rabat",
      profession:      "Députée",
      employer:        "Parlement du Maroc",
      sourceOfFunds:   "Indemnités parlementaires",
      customerType:    "INDIVIDUAL" as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "HIGH"       as const,
      riskScore:       68,
      pepStatus:       true,
      sanctionStatus:  "CLEAR"      as const,
      notes:           "PEP — Membre de la commission des finances.",
      lastReviewDate:  daysAgo(15),
      nextReviewDate:  daysAgo(-350),
      assignedAnalyst: analyst.id,
    },

    // ── Client à risque CRITICAL ──────────────────────────────────────────────
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "Hassan",
      lastName:        "QADIRI",
      email:           "h.qadiri@protonmail.com",
      phone:           "+212666789006",
      dateOfBirth:     "1955-12-01",
      nationality:     "MA",
      residenceCountry:"AE",             // Résidence aux Émirats
      address:         "Palm Jumeirah, Dubai",
      city:            "Dubai",
      profession:      "Homme d'affaires",
      sourceOfFunds:   "Investissements",
      customerType:    "INDIVIDUAL" as const,
      kycStatus:       "UNDER_REVIEW" as const,
      riskLevel:       "CRITICAL"   as const,
      riskScore:       91,
      pepStatus:       false,
      sanctionStatus:  "REVIEW"     as const,
      notes:           "Transactions multiples vers juridictions à risque. Dossier en cours d'investigation.",
      lastReviewDate:  daysAgo(5),
      nextReviewDate:  daysAgo(-10),
      assignedAnalyst: analyst.id,
    },

    // ── Clients CORPORATE ─────────────────────────────────────────────────────
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "MAROC",
      lastName:        "IMPORT EXPORT SARL",
      email:           "contact@mie-sarl.ma",
      phone:           "+212522345601",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "Zone Industrielle Ain Sebaâ",
      city:            "Casablanca",
      profession:      "Commerce international",
      sourceOfFunds:   "Activité commerciale",
      customerType:    "CORPORATE"  as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "MEDIUM"     as const,
      riskScore:       42,
      pepStatus:       false,
      sanctionStatus:  "CLEAR"      as const,
      lastReviewDate:  daysAgo(120),
      nextReviewDate:  daysAgo(-245),
      assignedAnalyst: analyst.id,
    },
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "ATLAS",
      lastName:        "HOLDING SA",
      email:           "direction@atlas-holding.ma",
      phone:           "+212537456702",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "Tour Atlas, Boulevard Zerktouni",
      city:            "Casablanca",
      profession:      "Holding — Immobilier & Finance",
      sourceOfFunds:   "Revenus locatifs et dividendes",
      customerType:    "CORPORATE"  as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "HIGH"       as const,
      riskScore:       65,
      pepStatus:       false,
      sanctionStatus:  "CLEAR"      as const,
      notes:           "Holding avec filiales dans 3 pays. Due diligence renforcée.",
      lastReviewDate:  daysAgo(20),
      nextReviewDate:  daysAgo(-345),
      assignedAnalyst: analyst.id,
    },
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "SHELL",
      lastName:        "HOLDINGS BVI LTD",
      email:           "admin@shell-bvi.com",
      phone:           "+18005551234",
      nationality:     "VG",            // British Virgin Islands
      residenceCountry:"VG",
      address:         "Road Town, Tortola",
      city:            "Tortola",
      profession:      "Société offshore",
      sourceOfFunds:   "Inconnu",
      customerType:    "CORPORATE"  as const,
      kycStatus:       "PENDING"    as const,
      riskLevel:       "CRITICAL"   as const,
      riskScore:       95,
      pepStatus:       false,
      sanctionStatus:  "REVIEW"     as const,
      notes:           "Société offshore BVI — bénéficiaire effectif non identifié. KYC en cours.",
      lastReviewDate:  daysAgo(2),
      nextReviewDate:  daysAgo(-7),
      assignedAnalyst: analyst.id,
    },
    {
      customerId:      `CLI-${uid()}`,
      firstName:       "CASABLANCA",
      lastName:        "FINANCE GROUP",
      email:           "compliance@cfg-bank.ma",
      phone:           "+212522456803",
      nationality:     "MA",
      residenceCountry:"MA",
      address:         "Casablanca Finance City",
      city:            "Casablanca",
      profession:      "Services financiers",
      sourceOfFunds:   "Activité bancaire",
      customerType:    "CORPORATE"  as const,
      kycStatus:       "APPROVED"   as const,
      riskLevel:       "LOW"        as const,
      riskScore:       15,
      pepStatus:       false,
      sanctionStatus:  "CLEAR"      as const,
      lastReviewDate:  daysAgo(180),
      nextReviewDate:  daysAgo(-185),
      assignedAnalyst: analyst.id,
    },
    // Clients supplémentaires pour volume
    {
      customerId:`CLI-${uid()}`, firstName:"Sara",   lastName:"BENKIRANE",
      email:"s.benkirane@gmail.com", phone:"+212667890107",
      dateOfBirth:"1995-06-20", nationality:"MA", residenceCountry:"MA",
      city:"Marrakech", profession:"Architecte", sourceOfFunds:"Salaire",
      customerType:"INDIVIDUAL" as const, kycStatus:"APPROVED" as const,
      riskLevel:"LOW" as const, riskScore:10, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
    },
    {
      customerId:`CLI-${uid()}`, firstName:"Omar",   lastName:"CHRAIBI",
      email:"o.chraibi@outlook.com", phone:"+212668901208",
      dateOfBirth:"1980-02-14", nationality:"MA", residenceCountry:"FR",
      city:"Paris", profession:"Entrepreneur", sourceOfFunds:"Dividendes",
      customerType:"INDIVIDUAL" as const, kycStatus:"APPROVED" as const,
      riskLevel:"MEDIUM" as const, riskScore:38, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
      notes:"Résident France — transactions entre France et Maroc fréquentes.",
    },
    {
      customerId:`CLI-${uid()}`, firstName:"Zineb",  lastName:"MOUSSAOUI",
      email:"z.moussaoui@labft.ma", phone:"+212669012309",
      dateOfBirth:"1988-10-05", nationality:"MA", residenceCountry:"MA",
      city:"Agadir", profession:"Directrice commerciale", sourceOfFunds:"Salaire",
      customerType:"INDIVIDUAL" as const, kycStatus:"APPROVED" as const,
      riskLevel:"LOW" as const, riskScore:7, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
    },
    {
      customerId:`CLI-${uid()}`, firstName:"Yassine", lastName:"HAFIDI",
      email:"y.hafidi@proton.me", phone:"+212670123410",
      dateOfBirth:"1975-08-25", nationality:"MA", residenceCountry:"MA",
      city:"Casablanca", profession:"Consultant", sourceOfFunds:"Honoraires",
      customerType:"INDIVIDUAL" as const, kycStatus:"UNDER_REVIEW" as const,
      riskLevel:"HIGH" as const, riskScore:74, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
      notes:"Flux financiers inhabituels détectés en janvier 2026.",
    },
    {
      customerId:`CLI-${uid()}`, firstName:"GREEN",   lastName:"ENERGY MAROC SARL",
      email:"finance@green-energy.ma", phone:"+212528234511",
      nationality:"MA", residenceCountry:"MA",
      city:"Casablanca", profession:"Énergie renouvelable", sourceOfFunds:"Contrats d'État",
      customerType:"CORPORATE" as const, kycStatus:"APPROVED" as const,
      riskLevel:"LOW" as const, riskScore:18, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
    },
    {
      customerId:`CLI-${uid()}`, firstName:"Ibrahim",  lastName:"DIALLO",
      email:"i.diallo@gmail.com", phone:"+221771234512",
      dateOfBirth:"1983-04-17", nationality:"SN", residenceCountry:"MA",
      city:"Casablanca", profession:"Commerçant", sourceOfFunds:"Commerce textile",
      customerType:"INDIVIDUAL" as const, kycStatus:"APPROVED" as const,
      riskLevel:"MEDIUM" as const, riskScore:44, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
      notes:"Ressortissant sénégalais résident. Transferts réguliers vers Dakar.",
    },
    {
      customerId:`CLI-${uid()}`, firstName:"Meryem",  lastName:"LAHLOU",
      email:"m.lahlou@hotmail.fr", phone:"+212671234613",
      dateOfBirth:"1992-01-30", nationality:"MA", residenceCountry:"MA",
      city:"Casablanca", profession:"Pharmacienne", sourceOfFunds:"Salaire",
      customerType:"INDIVIDUAL" as const, kycStatus:"APPROVED" as const,
      riskLevel:"LOW" as const, riskScore:9, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
    },
    {
      customerId:`CLI-${uid()}`, firstName:"Abdelkader", lastName:"ZIANI",
      email:"a.ziani@gmail.com", phone:"+213555123714",
      dateOfBirth:"1969-07-03", nationality:"DZ", residenceCountry:"DZ",
      city:"Alger", profession:"Importateur", sourceOfFunds:"Commerce",
      customerType:"INDIVIDUAL" as const, kycStatus:"APPROVED" as const,
      riskLevel:"MEDIUM" as const, riskScore:45, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
    },
    {
      customerId:`CLI-${uid()}`, firstName:"TECH",     lastName:"INVEST SARL",
      email:"gestion@tech-invest.ma", phone:"+212522789815",
      nationality:"MA", residenceCountry:"MA",
      city:"Rabat", profession:"Capital-risque", sourceOfFunds:"Investissements",
      customerType:"CORPORATE" as const, kycStatus:"APPROVED" as const,
      riskLevel:"MEDIUM" as const, riskScore:40, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
    },
    {
      customerId:`CLI-${uid()}`, firstName:"Hamid",   lastName:"OUALI",
      email:"h.ouali@yahoo.fr", phone:"+212672345916",
      dateOfBirth:"1960-11-22", nationality:"MA", residenceCountry:"MA",
      city:"Tanger", profession:"Armateur", sourceOfFunds:"Transport maritime",
      customerType:"INDIVIDUAL" as const, kycStatus:"APPROVED" as const,
      riskLevel:"HIGH" as const, riskScore:70, pepStatus:false,
      sanctionStatus:"CLEAR" as const,
      notes:"Activité portuaire — surveillance flux cash importants.",
    },
  ];

  const inserted = await db.insert(schema.customers).values(customersData as any).returning();
  console.log(`   ✓ ${inserted.length} clients créés`);
  return inserted;
}

// ─── 3. TRANSACTIONS ──────────────────────────────────────────────────────────

async function seedTransactions(customers: typeof schema.customers.$inferSelect[]) {
  console.log("\n💸 Création des transactions...");

  const qadiri  = customers.find(c => c.lastName === "QADIRI")!;
  const alami   = customers.find(c => c.lastName === "ALAMI")!;
  const shell   = customers.find(c => c.lastName.includes("HOLDINGS BVI"))!;
  const atlas   = customers.find(c => c.lastName.includes("ATLAS"))!;
  const hafidi  = customers.find(c => c.lastName === "HAFIDI")!;
  const bensouda= customers.find(c => c.lastName === "BENSOUDA")!;
  const tazi    = customers.find(c => c.lastName === "TAZI")!;
  const mie     = customers.find(c => c.lastName.includes("IMPORT EXPORT"))!;
  const berrada = customers.find(c => c.lastName === "BERRADA")!;
  const chraibi = customers.find(c => c.lastName === "CHRAIBI")!;

  const transactions = [

    // ── Transactions SUSPECTES (déclenchent alertes) ──────────────────────────

    // Qadiri — virement massif vers BVI (CRITIQUE)
    {
      transactionId:       txId(),
      customerId:          qadiri.id,
      amount:              "485000.00",
      currency:            "MAD",
      transactionType:     "TRANSFER"   as const,
      channel:             "ONLINE"     as const,
      counterparty:        "Shell Holdings BVI Ltd",
      counterpartyCountry: "VG",
      counterpartyBank:    "VP Bank BVI",
      purpose:             "Prestation de conseil international",
      riskScore:           94,
      status:              "FLAGGED"    as const,
      isSuspicious:        true,
      flagReason:          "HIGH_AMOUNT + HIGH_RISK_COUNTRY + STRUCTURING",
      transactionDate:     hoursAgo(2),
      riskRules:           JSON.stringify([
        { rule: "HIGH_AMOUNT",       score: 45, reason: "485 000 MAD > seuil 10 000 MAD" },
        { rule: "HIGH_RISK_COUNTRY", score: 40, reason: "Destination BVI — liste FATF" },
        { rule: "PEP_TRANSACTION",   score: 15, reason: "Client sous surveillance renforcée" },
      ]),
    },
    // Qadiri — structuring (3 virements en dessous du seuil)
    {
      transactionId: txId(), customerId: qadiri.id,
      amount: "9800.00", currency: "MAD",
      transactionType: "TRANSFER" as const, channel: "ONLINE" as const,
      counterparty: "Hassan Qadiri Jr", purpose: "Virement famille",
      riskScore: 72, status: "FLAGGED" as const, isSuspicious: true,
      flagReason: "STRUCTURING_PATTERN",
      transactionDate: hoursAgo(6),
    },
    {
      transactionId: txId(), customerId: qadiri.id,
      amount: "9500.00", currency: "MAD",
      transactionType: "TRANSFER" as const, channel: "MOBILE" as const,
      counterparty: "Hassan Qadiri Jr", purpose: "Virement famille",
      riskScore: 72, status: "FLAGGED" as const, isSuspicious: true,
      flagReason: "STRUCTURING_PATTERN",
      transactionDate: hoursAgo(12),
    },
    {
      transactionId: txId(), customerId: qadiri.id,
      amount: "9200.00", currency: "MAD",
      transactionType: "TRANSFER" as const, channel: "BRANCH" as const,
      counterparty: "Hassan Qadiri Jr", purpose: "Virement famille",
      riskScore: 72, status: "FLAGGED" as const, isSuspicious: true,
      flagReason: "STRUCTURING_PATTERN",
      transactionDate: daysAgo(1),
    },

    // Shell BVI — dépôt cash suspect
    {
      transactionId: txId(), customerId: shell.id,
      amount: "250000.00", currency: "MAD",
      transactionType: "DEPOSIT" as const, channel: "BRANCH" as const,
      purpose: "Apport en capital", riskScore: 95,
      status: "BLOCKED" as const, isSuspicious: true,
      flagReason: "UNVERIFIED_SOURCE + HIGH_RISK_JURISDICTION + KYC_PENDING",
      transactionDate: daysAgo(1),
    },

    // Hafidi — transactions anormales vs historique
    {
      transactionId: txId(), customerId: hafidi.id,
      amount: "75000.00", currency: "MAD",
      transactionType: "TRANSFER" as const, channel: "ONLINE" as const,
      counterparty: "Offshore Ventures Ltd", counterpartyCountry: "KY",
      purpose: "Services consulting", riskScore: 82,
      status: "FLAGGED" as const, isSuspicious: true,
      flagReason: "HIGH_AMOUNT + HIGH_RISK_COUNTRY + VOLUME_SPIKE",
      transactionDate: daysAgo(3),
    },
    {
      transactionId: txId(), customerId: hafidi.id,
      amount: "68000.00", currency: "MAD",
      transactionType: "TRANSFER" as const, channel: "ONLINE" as const,
      counterparty: "Offshore Ventures Ltd", counterpartyCountry: "KY",
      purpose: "Services consulting", riskScore: 80,
      status: "FLAGGED" as const, isSuspicious: true,
      flagReason: "HIGH_AMOUNT + HIGH_RISK_COUNTRY",
      transactionDate: daysAgo(7),
    },

    // Bensouda (PEP) — virement étranger
    {
      transactionId: txId(), customerId: bensouda.id,
      amount: "150000.00", currency: "MAD",
      transactionType: "TRANSFER" as const, channel: "WIRE" as const,
      counterparty: "Swiss Private Bank", counterpartyCountry: "CH",
      counterpartyBank: "Credit Suisse Zurich",
      purpose: "Placement épargne",
      riskScore: 75, status: "FLAGGED" as const, isSuspicious: true,
      flagReason: "PEP_TRANSACTION + HIGH_AMOUNT + FOREIGN_TRANSFER",
      transactionDate: daysAgo(5),
    },

    // Atlas — transaction suspecte entre entités liées
    {
      transactionId: txId(), customerId: atlas.id,
      amount: "320000.00", currency: "MAD",
      transactionType: "TRANSFER" as const, channel: "API" as const,
      counterparty: "Atlas Real Estate BVI", counterpartyCountry: "VG",
      purpose: "Acquisition immobilière offshore",
      riskScore: 88, status: "FLAGGED" as const, isSuspicious: true,
      flagReason: "HIGH_AMOUNT + HIGH_RISK_COUNTRY + CORPORATE_OFFSHORE",
      transactionDate: daysAgo(2),
    },

    // MIE — importation — transaction normale montant élevé
    {
      transactionId: txId(), customerId: mie.id,
      amount: "820000.00", currency: "MAD",
      transactionType: "PAYMENT" as const, channel: "WIRE" as const,
      counterparty: "Guangdong Trading Co", counterpartyCountry: "CN",
      counterpartyBank: "Bank of China",
      purpose: "Paiement marchandises import — LC n° 2026-0342",
      riskScore: 28, status: "COMPLETED" as const, isSuspicious: false,
      transactionDate: daysAgo(4),
    },

    // ── Transactions NORMALES ──────────────────────────────────────────────────

    { transactionId:txId(), customerId:alami.id, amount:"12500.00", currency:"MAD",
      transactionType:"TRANSFER" as const, channel:"ONLINE" as const,
      counterparty:"Fatima Alami", purpose:"Loyer mensuel",
      riskScore:5, status:"COMPLETED" as const, isSuspicious:false,
      transactionDate:daysAgo(2) },

    { transactionId:txId(), customerId:alami.id, amount:"3200.00", currency:"MAD",
      transactionType:"PAYMENT" as const, channel:"MOBILE" as const,
      counterparty:"Marjane Casablanca", purpose:"Courses alimentaires",
      riskScore:2, status:"COMPLETED" as const, isSuspicious:false,
      transactionDate:daysAgo(3) },

    { transactionId:txId(), customerId:berrada.id, amount:"8500.00", currency:"MAD",
      transactionType:"TRANSFER" as const, channel:"ONLINE" as const,
      counterparty:"Cabinet Médical Rabat", purpose:"Achat matériel médical",
      riskScore:4, status:"COMPLETED" as const, isSuspicious:false,
      transactionDate:daysAgo(1) },

    { transactionId:txId(), customerId:tazi.id, amount:"45000.00", currency:"MAD",
      transactionType:"PAYMENT" as const, channel:"BRANCH" as const,
      counterparty:"Fournisseur Fès El Bali", purpose:"Stock marchandises été",
      riskScore:22, status:"COMPLETED" as const, isSuspicious:false,
      transactionDate:daysAgo(6) },

    { transactionId:txId(), customerId:chraibi.id, amount:"35000.00", currency:"EUR",
      transactionType:"TRANSFER" as const, channel:"WIRE" as const,
      counterparty:"Mohammed Chraibi", counterpartyCountry:"MA",
      counterpartyBank:"Attijariwafa Bank",
      purpose:"Transfert familial Maroc",
      riskScore:18, status:"COMPLETED" as const, isSuspicious:false,
      transactionDate:daysAgo(8) },

    { transactionId:txId(), customerId:alami.id, amount:"25000.00", currency:"MAD",
      transactionType:"DEPOSIT" as const, channel:"ATM" as const,
      purpose:"Dépôt salaire", riskScore:3,
      status:"COMPLETED" as const, isSuspicious:false, transactionDate:daysAgo(10) },

    { transactionId:txId(), customerId:berrada.id, amount:"2500.00", currency:"MAD",
      transactionType:"WITHDRAWAL" as const, channel:"ATM" as const,
      purpose:"Retrait espèces", riskScore:2,
      status:"COMPLETED" as const, isSuspicious:false, transactionDate:daysAgo(4) },

    { transactionId:txId(), customerId:tazi.id, amount:"15000.00", currency:"MAD",
      transactionType:"TRANSFER" as const, channel:"ONLINE" as const,
      counterparty:"Mohamed Tazi SARL", purpose:"Virement compte pro",
      riskScore:14, status:"COMPLETED" as const, isSuspicious:false,
      transactionDate:daysAgo(12) },

    // Transactions historiques pour stats dashboard
    { transactionId:txId(), customerId:alami.id, amount:"12000.00", currency:"MAD",
      transactionType:"TRANSFER" as const, channel:"ONLINE" as const,
      purpose:"Loyer mensuel", riskScore:5,
      status:"COMPLETED" as const, isSuspicious:false, transactionDate:daysAgo(32) },

    { transactionId:txId(), customerId:mie.id, amount:"1200000.00", currency:"MAD",
      transactionType:"PAYMENT" as const, channel:"WIRE" as const,
      counterparty:"Turkish Textile Ltd", counterpartyCountry:"TR",
      purpose:"Import textiles — commande Q4", riskScore:30,
      status:"COMPLETED" as const, isSuspicious:false, transactionDate:daysAgo(45) },
  ];

  const inserted = await db.insert(schema.transactions).values(transactions as any).returning();
  console.log(`   ✓ ${inserted.length} transactions créées`);
  console.log(`   ↳ ${transactions.filter(t => t.isSuspicious).length} suspectes`);
  console.log(`   ↳ ${transactions.filter(t => t.status === "BLOCKED").length} bloquées`);
  return inserted;
}

// ─── 4. ALERTES ───────────────────────────────────────────────────────────────

async function seedAlerts(
  customers: typeof schema.customers.$inferSelect[],
  transactions: typeof schema.transactions.$inferSelect[],
  users: typeof schema.users.$inferSelect[],
) {
  console.log("\n🚨 Création des alertes...");

  const analyst   = users.find(u => u.role === "analyst")!;
  const supervisor= users.find(u => u.role === "supervisor")!;
  const qadiri    = customers.find(c => c.lastName === "QADIRI")!;
  const shell     = customers.find(c => c.lastName.includes("HOLDINGS BVI"))!;
  const hafidi    = customers.find(c => c.lastName === "HAFIDI")!;
  const bensouda  = customers.find(c => c.lastName === "BENSOUDA")!;
  const atlas     = customers.find(c => c.lastName.includes("ATLAS"))!;

  const suspTx = transactions.filter(t => t.isSuspicious);

  const alerts = [
    // CRITICAL
    {
      alertId:    altId(),
      customerId: qadiri.id,
      transactionId: suspTx[0]?.id ?? null,
      scenario:   "HIGH_AMOUNT + HIGH_RISK_COUNTRY + STRUCTURING",
      alertType:  "THRESHOLD"  as const,
      priority:   "CRITICAL"   as const,
      status:     "OPEN"       as const,
      riskScore:  94,
      reason:     "Virement 485 000 MAD vers BVI — 3 règles FATF déclenchées. Structuring détecté (3 virements sous seuil en 24h). Déclaration SAR requise.",
      createdAt:  hoursAgo(2),
      enrichmentData: JSON.stringify({
        triggeredRules: [
          { rule: "HIGH_AMOUNT", score: 45 },
          { rule: "HIGH_RISK_COUNTRY", score: 40 },
          { rule: "STRUCTURING", score: 35 },
        ],
        customer: { riskLevel: "CRITICAL", pepStatus: false },
      }),
    },
    {
      alertId:    altId(),
      customerId: shell.id,
      transactionId: suspTx.find(t => t.customerId === shell.id)?.id ?? null,
      scenario:   "UNVERIFIED_SOURCE + HIGH_RISK_JURISDICTION + KYC_PENDING",
      alertType:  "COMPLIANCE" as const,
      priority:   "CRITICAL"   as const,
      status:     "IN_REVIEW"  as const,
      riskScore:  95,
      reason:     "Transaction bloquée — société BVI, KYC non finalisé, source des fonds inconnue.",
      assignedTo: supervisor.id,
      createdAt:  daysAgo(1),
    },
    // HIGH
    {
      alertId:    altId(),
      customerId: hafidi.id,
      transactionId: suspTx.find(t => t.customerId === hafidi.id)?.id ?? null,
      scenario:   "HIGH_AMOUNT + HIGH_RISK_COUNTRY + VOLUME_SPIKE",
      alertType:  "FRAUD"      as const,
      priority:   "HIGH"       as const,
      status:     "OPEN"       as const,
      riskScore:  82,
      reason:     "Deux virements vers Caïmans en 4 jours (143 000 MAD). Variation volume +340% vs moyenne.",
      assignedTo: analyst.id,
      createdAt:  daysAgo(3),
    },
    {
      alertId:    altId(),
      customerId: bensouda.id,
      transactionId: suspTx.find(t => t.customerId === bensouda.id)?.id ?? null,
      scenario:   "PEP_TRANSACTION + HIGH_AMOUNT + FOREIGN_TRANSFER",
      alertType:  "THRESHOLD"  as const,
      priority:   "HIGH"       as const,
      status:     "IN_REVIEW"  as const,
      riskScore:  75,
      reason:     "Client PEP — virement 150 000 MAD vers Suisse. Surveillance renforcée AMLD6 Art. 18.",
      assignedTo: supervisor.id,
      createdAt:  daysAgo(5),
    },
    {
      alertId:    altId(),
      customerId: atlas.id,
      transactionId: suspTx.find(t => t.customerId === atlas.id)?.id ?? null,
      scenario:   "HIGH_AMOUNT + HIGH_RISK_COUNTRY + CORPORATE_OFFSHORE",
      alertType:  "THRESHOLD"  as const,
      priority:   "HIGH"       as const,
      status:     "OPEN"       as const,
      riskScore:  88,
      reason:     "Holding — virement 320 000 MAD vers entité liée offshore BVI. Structure opaque.",
      createdAt:  daysAgo(2),
    },
    // MEDIUM
    {
      alertId:    altId(),
      customerId: qadiri.id,
      transactionId: suspTx[1]?.id ?? null,
      scenario:   "STRUCTURING_PATTERN",
      alertType:  "VELOCITY"   as const,
      priority:   "MEDIUM"     as const,
      status:     "OPEN"       as const,
      riskScore:  72,
      reason:     "3 virements successifs juste sous le seuil de déclaration (9 200 – 9 500 – 9 800 MAD) en 24h.",
      createdAt:  daysAgo(1),
    },
    // RESOLVED
    {
      alertId:    altId(),
      customerId: customers.find(c => c.lastName === "TAZI")!.id,
      scenario:   "HIGH_FREQUENCY",
      alertType:  "VELOCITY"   as const,
      priority:   "MEDIUM"     as const,
      status:     "RESOLVED"   as const,
      riskScore:  45,
      reason:     "Fréquence transactions anormale — 8 paiements en 2 jours.",
      assignedTo: analyst.id,
      resolvedAt: daysAgo(3),
      resolutionNote: "Vérifié — période de fin de saison commerciale. Activité légitime confirmée.",
      createdAt:  daysAgo(8),
    },
    {
      alertId:    altId(),
      customerId: customers.find(c => c.lastName === "CHRAIBI")!.id,
      scenario:   "FOREIGN_TRANSFER",
      alertType:  "COMPLIANCE" as const,
      priority:   "LOW"        as const,
      status:     "FALSE_POSITIVE" as const,
      riskScore:  28,
      reason:     "Transfert vers Maroc — vérification origine des fonds.",
      assignedTo: analyst.id,
      resolvedAt: daysAgo(5),
      resolutionNote: "Virement familial confirmé par justificatifs. Faux positif.",
      createdAt:  daysAgo(10),
    },
  ];

  const inserted = await db.insert(schema.alerts).values(alerts as any).returning();
  console.log(`   ✓ ${inserted.length} alertes créées`);
  console.log(`   ↳ ${alerts.filter(a => a.priority === "CRITICAL").length} CRITICAL`);
  console.log(`   ↳ ${alerts.filter(a => a.priority === "HIGH").length} HIGH`);
  console.log(`   ↳ ${alerts.filter(a => a.status === "OPEN").length} ouvertes`);
  return inserted;
}

// ─── 5. DOSSIERS ──────────────────────────────────────────────────────────────

async function seedCases(
  customers: typeof schema.customers.$inferSelect[],
  users: typeof schema.users.$inferSelect[],
) {
  console.log("\n📁 Création des dossiers...");

  const analyst   = users.find(u => u.role === "analyst")!;
  const supervisor= users.find(u => u.role === "supervisor")!;
  const co        = users.find(u => u.role === "compliance_officer")!;
  const qadiri    = customers.find(c => c.lastName === "QADIRI")!;
  const shell     = customers.find(c => c.lastName.includes("HOLDINGS BVI"))!;
  const hafidi    = customers.find(c => c.lastName === "HAFIDI")!;

  const cases = [
    {
      caseId:      caseId(),
      customerId:  qadiri.id,
      title:       "Investigation — Transactions offshore multiples QADIRI Hassan",
      description: "Client CRITICAL — Série de virements vers juridictions à risque (BVI, Panama). Structuring détecté. SAR en préparation.",
      severity:    "CRITICAL" as const,
      status:      "OPEN"     as const,
      assignedTo:  supervisor.id,
      createdBy:   analyst.id,
      dueDate:     daysAgo(-5),
      createdAt:   hoursAgo(3),
    },
    {
      caseId:      caseId(),
      customerId:  shell.id,
      title:       "KYC Renforcé — Shell Holdings BVI Ltd",
      description: "Société offshore — bénéficiaire effectif non identifié. Transaction bloquée en attente de documentation KYC complète.",
      severity:    "CRITICAL" as const,
      status:      "IN_PROGRESS" as const,
      assignedTo:  co.id,
      createdBy:   supervisor.id,
      dueDate:     daysAgo(-3),
      createdAt:   daysAgo(1),
    },
    {
      caseId:      caseId(),
      customerId:  hafidi.id,
      title:       "Surveillance — Flux inhabituels HAFIDI Yassine",
      description: "Variation de volume +340%. Deux virements vers Caïmans en 4 jours. Vérification source des fonds en cours.",
      severity:    "HIGH"     as const,
      status:      "IN_PROGRESS" as const,
      assignedTo:  analyst.id,
      createdBy:   analyst.id,
      dueDate:     daysAgo(-10),
      createdAt:   daysAgo(3),
    },
    {
      caseId:      caseId(),
      customerId:  customers.find(c => c.lastName === "BENSOUDA")!.id,
      title:       "Revue annuelle PEP — BENSOUDA Rachid",
      description: "Revue annuelle obligatoire client PEP. Mise à jour déclaration patrimoine et source des fonds.",
      severity:    "MEDIUM"   as const,
      status:      "OPEN"     as const,
      assignedTo:  co.id,
      createdBy:   co.id,
      dueDate:     daysAgo(-15),
      createdAt:   daysAgo(5),
    },
  ];

  const inserted = await db.insert(schema.cases).values(cases as any).returning();
  console.log(`   ✓ ${inserted.length} dossiers créés`);
  return inserted;
}

// ─── 6. SCREENING ─────────────────────────────────────────────────────────────

async function seedScreening(customers: typeof schema.customers.$inferSelect[]) {
  console.log("\n🔍 Création des résultats de screening...");

  const qadiri = customers.find(c => c.lastName === "QADIRI")!;
  const shell  = customers.find(c => c.lastName.includes("HOLDINGS BVI"))!;
  const alami  = customers.find(c => c.lastName === "ALAMI")!;
  const berrada= customers.find(c => c.lastName === "BERRADA")!;
  const tazi   = customers.find(c => c.lastName === "TAZI")!;
  const atlas  = customers.find(c => c.lastName.includes("ATLAS"))!;

  const screenings = [
    // MATCH — shell company connue
    {
      customerId:    shell.id,
      screeningType: "SANCTIONS" as const,
      status:        "REVIEW"    as const,
      matchScore:    72,
      matchedEntity: "Shell Holdings International (sanctionné UE 2021)",
      listSource:    "EU Consolidated List",
      confidenceScore: 72,
      decision:      "PENDING"   as const,
      details:       JSON.stringify({ matchedAlias: "Shell Holdings", method: "fuzzy_nlp", score: 72 }),
      createdAt:     daysAgo(2),
    },
    // REVIEW — nom similaire liste OFAC
    {
      customerId:    qadiri.id,
      screeningType: "SANCTIONS" as const,
      status:        "REVIEW"    as const,
      matchScore:    58,
      matchedEntity: "Qadiri Hassan Akbar (OFAC SDN)",
      listSource:    "OFAC SDN List",
      confidenceScore: 58,
      decision:      "PENDING"   as const,
      details:       JSON.stringify({ matchedAlias: "Qadiri H.", method: "fuzzy_nlp", score: 58 }),
      createdAt:     hoursAgo(3),
    },
    // CLEAR — clients normaux
    {
      customerId:    alami.id,
      screeningType: "SANCTIONS" as const,
      status:        "CLEAR"     as const,
      matchScore:    0,
      matchedEntity: null,
      listSource:    "OFAC SDN List",
      confidenceScore: 0,
      decision:      "CLEARED"   as const,
      createdAt:     daysAgo(90),
    },
    {
      customerId:    berrada.id,
      screeningType: "SANCTIONS" as const,
      status:        "CLEAR"     as const,
      matchScore:    0,
      matchedEntity: null,
      listSource:    "EU Consolidated List",
      confidenceScore: 0,
      decision:      "CLEARED"   as const,
      createdAt:     daysAgo(45),
    },
    {
      customerId:    tazi.id,
      screeningType: "SANCTIONS" as const,
      status:        "CLEAR"     as const,
      matchScore:    12,
      matchedEntity: null,
      listSource:    "UN Consolidated List",
      confidenceScore: 12,
      decision:      "CLEARED"   as const,
      details:       JSON.stringify({ note: "Correspondance partielle sur prénom uniquement — éliminée" }),
      createdAt:     daysAgo(60),
    },
    {
      customerId:    atlas.id,
      screeningType: "SANCTIONS" as const,
      status:        "CLEAR"     as const,
      matchScore:    5,
      matchedEntity: null,
      listSource:    "UK HM Treasury",
      confidenceScore: 5,
      decision:      "CLEARED"   as const,
      createdAt:     daysAgo(20),
    },
  ];

  const inserted = await db.insert(schema.screeningResults).values(screenings as any).returning();
  console.log(`   ✓ ${inserted.length} résultats de screening créés`);
  console.log(`   ↳ ${screenings.filter(s => s.status === "REVIEW").length} en révision`);
  console.log(`   ↳ ${screenings.filter(s => s.status === "CLEAR").length} CLEAR`);
  return inserted;
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────

async function main() {
  console.log("🌱 KYC-AML v2 — Seed de démonstration");
  console.log("========================================");

  try {
    if (RESET) {
      await resetDb();
    } else {
      // Vérifier si des données existent déjà
      const existing = await db.select().from(schema.users).limit(1);
      if (existing.length > 0) {
        console.log("⚠️  Des données existent déjà.");
        console.log("   Utiliser --reset pour écraser : pnpm tsx drizzle/seed.demo.ts --reset");
        process.exit(0);
      }
    }

    const users        = await seedUsers();
    const customers    = await seedCustomers(users);
    const transactions = await seedTransactions(customers);
    const alerts       = await seedAlerts(customers, transactions, users);
    await seedCases(customers, users);
    await seedScreening(customers);

    console.log("\n========================================");
    console.log("✅ Seed terminé avec succès !\n");
    console.log("📊 Résumé :");
    console.log(`   👥 ${users.length} utilisateurs`);
    console.log(`   🏦 ${customers.length} clients (dont 2 PEP, 2 CRITICAL)`);
    console.log(`   💸 ${transactions.length} transactions`);
    console.log(`   🚨 ${alerts.length} alertes`);
    console.log("\n🔐 Connexion admin :");
    console.log("   URL      : http://localhost:5173/login");
    console.log("   Email    : admin@labft.ma");
    console.log("   Password : Admin2026!LabFT");
    console.log("\n🔗 Test webhook CBS :");
    console.log(`   customerId disponible : ${customers[0]!.id} (Mohammed ALAMI)`);
    console.log(`   curl -X POST http://localhost:3000/webhooks/transaction \\`);
    console.log(`     -H "Content-Type: application/json" \\`);
    console.log(`     -d '{"transactionId":"TEST-001","customerId":${customers[0]!.id},"amount":"50000","currency":"MAD","transactionType":"TRANSFER","timestamp":${Date.now()}}'`);

  } catch (err) {
    console.error("\n❌ Erreur seed :", err);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();
